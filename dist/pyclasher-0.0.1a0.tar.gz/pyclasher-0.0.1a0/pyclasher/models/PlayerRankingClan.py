from .BaseModels import BaseClan


class PlayerRankingClan(BaseClan):
    pass
