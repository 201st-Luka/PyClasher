from .BulkPlayer import PlayerBulkRequest
